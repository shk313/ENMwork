setwd("~/dropbox/suzanne")

cont<-raster("./continent_raster/continent.bil")
cont_fine<-raster("./continent_raster/cont_fine.bil")
cont008<-raster("./continent_raster/cont_008.bil")
load("A_aegypti_1_data.RData")
load("A_africanus_1_data.RData")
afr.df<-A.africanus.1.data
aeg.df<-A.aegypti.1.data
aeg.df[1:5,]

xx<-extract(cont, aeg.df)
xx.fine<-extract(cont_fine,aeg.df)
xx008<-extract(cont008,aeg.df)
alt<-raster("~/dropbox/kate_mres/new_paper/altbil/alt.bil")

xxalt<-extract(alt,aeg.df)
source("adj.coords.R")

new.coords<-adj.coords(cont008,aeg.df)

xx.afr<-extract(cont,afr.df)
afr.cont008<-extract(cont008,afr.df)

afr.df$cont<-afr.cont008

#remove NAs
afr.df.noNA<-afr.df[!is.na(afr.df$cont),]

afr.df.noNA$species<-"A_africanus"
afr.df.noNA<-afr.df.noNA[,c(4,3,1,2)]

#if multiple contients, tidy and order following below code.

asdf<-afr.df.noNA
asdf$cont[sample(nrow(asdf),20)]<-3

asdf.1<-asdf[asdf$cont==1,]
asdf.3<-asdf[asdf$cont==3,]

asdf2.3<-asdf.3
asdf.3$species<-"pancake"

asdf4<-rbind(asdf.3,asdf2.3)

#put dataframes into a list
asdf.list<-list(asdf.3,asdf2.3)
names(asdf.list)<-c("pancake","A_africanus")


#a small loop to find the number of rows in each list element
xx.list<-list()
for (L in 1:length(asdf.list)) {
	xx.list[[L]]<-nrow(asdf.list[[L]])
	
	
}


